int main() {
    double *p = new double[1000];
    delete p;
    return 0;
}
