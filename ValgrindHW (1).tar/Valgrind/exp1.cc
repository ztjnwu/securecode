int main() {
    [[maybe_unused]] char *x = new char[100];
    return 0;
}
